(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__0_zbhso._.css","static/chunks/node_modules_10fojmb._.js","static/chunks/src_1ae5p0x._.js","static/chunks/node_modules_1yb-035._.js","static/chunks/src_components_0ctotw4._.js","static/chunks/src_components_ui_table_tsx_0lwjh3x._.js"],
    source: "entry"
});
